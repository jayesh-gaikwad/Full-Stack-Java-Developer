package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.bo.CustomerBO;
import in.ineuron.dao.ICustomerDAO;
import in.ineuron.dto.CustomerDTO;

@Service(value = "service")
public class CustomerMgmtServiceImpl implements ICustomerMgmntService {

	static {
		System.out.println("CustomerMgmtServiceImpl.class file loading...");
	}

	public CustomerMgmtServiceImpl() {
		System.out.println("CustomerMgmtServiceImpl zero paramter constructor");
	}

	@Autowired
	private ICustomerDAO dao;

	@Override
	public String calculateSimpleInterest(CustomerDTO dto) throws Exception {
		float intrAmount = (dto.getPamt() * dto.getTime() * dto.getRate()) / 100.0f;
		CustomerBO customerBO = new CustomerBO();
		customerBO.setCustomerName(dto.getCustomerName());
		customerBO.setCustomerAddress(dto.getCustomerAddress());
		customerBO.setPamt(dto.getPamt());
		customerBO.setTime(dto.getTime());
		customerBO.setRate(dto.getRate());
		customerBO.setIntrAmount(intrAmount);

		int count = dao.save(customerBO);
		return count == 0 ? "Customer registration failed"
				: "customer registration successfull--->SimpleInterestAmount::" + intrAmount;

	}

}
