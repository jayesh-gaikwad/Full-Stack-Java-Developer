package in.ineuron.dao;

import java.sql.SQLException;

import in.ineuron.bo.CustomerBO;

public interface ICustomerDAO {
	public int save(CustomerBO customerBO) throws SQLException;
}
