package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import in.ineuron.dto.EmployeeDTO;
import in.ineuron.service.IEmployeeService;
import in.ineuron.vo.EmployeeVO;

@Component(value = "controller")
public class MainController {

	static {
		System.out.println("MainController .Class file is loading ");
	}

	public MainController() {
		System.out.println("MainController object is intantiated");
	}

	@Autowired
	public IEmployeeService service;

	public EmployeeVO getHike(EmployeeVO vo) {

		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEaddress(vo.getEaddress());
		employeeDTO.setEname(vo.getEname());
		employeeDTO.setEage(Integer.parseInt(vo.getEage()));
		employeeDTO.setEsalary(Float.parseFloat(vo.getEsalary()));

		EmployeeDTO empDTO = service.calculateHike(employeeDTO);

		EmployeeVO employeeVO = new EmployeeVO();
		employeeVO.setEid(empDTO.getEid().toString());
		employeeVO.setEaddress(empDTO.getEaddress());
		employeeVO.setEage(empDTO.getEage().toString());
		employeeVO.setEsalary(empDTO.getEsalary().toString());
		employeeVO.setEname(empDTO.getEname());
		employeeVO.setHikeAmt(empDTO.getHikeAmount().toString());

		return employeeVO;

	}

	@Override
	public String toString() {
		return "MainController [service=" + service + "]";
	}

}
