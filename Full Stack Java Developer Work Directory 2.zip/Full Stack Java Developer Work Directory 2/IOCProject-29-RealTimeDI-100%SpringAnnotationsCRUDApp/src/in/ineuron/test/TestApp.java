package in.ineuron.test;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import in.ineuron.cfg.AppConfig;
import in.ineuron.controller.MainController;
import in.ineuron.vo.EmployeeVO;

public class TestApp {

	public static void main(String[] args) throws IllegalArgumentException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the ename::");
		String ename = scanner.next();

		System.out.println("Enter the eage");
		String eage = scanner.next();

		System.out.println("Enter the eaddress");
		String eaddress = scanner.next();

		System.out.println("Enter the esalary");
		String esalary = scanner.next();

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		MainController controller = context.getBean(MainController.class);
		EmployeeVO vo = new EmployeeVO();
		vo.setEname(ename);	
		vo.setEage(eage);
		vo.setEaddress(eaddress);
		vo.setEsalary(esalary);

		EmployeeVO voResult = controller.getHike(vo);
		System.out.println(voResult);

		((AbstractApplicationContext) context).close();
		scanner.close();
	}

}
