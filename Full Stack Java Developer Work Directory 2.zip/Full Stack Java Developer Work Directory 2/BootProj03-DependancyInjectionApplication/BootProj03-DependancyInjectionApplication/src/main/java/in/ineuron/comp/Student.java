package in.ineuron.comp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Student {

	@Autowired(required = true)
	@Qualifier("uiCourse")
	private ICourse course;

	static {
		System.out.println("Student. class file is loading()");
	}

	public Student() {
		System.out.println("Student zero parameter constructor...");
	}

	public void preparation(String examName) {
		System.out.println("Student.preparation() ");
		System.out.println("Course choose is:: " + course.getClass().getName());

		String courseContent = course.courseContent();
		float price = course.price();
		System.out.println("Preparation is going on using " + courseContent + "material with price::" + price);
		System.out.println("Preparation Completed for " + examName);
	}

	public String toString() {
		return "Student[course=" + course + "]";

	}

}
