package in.ineuron.comp;

import org.springframework.stereotype.Component;

@Component(value="java")
public class JavaCourseMaterial implements ICourse {

	static {
		System.out.println("JavaCourseMaterial. class file is loading");
	}

	public JavaCourseMaterial() {
		System.out.println("JavaCourseMaterial :: Zero Parmeter Constuctor");
	}

	@Override
	public String courseContent() {
		System.out.println("JavaCourseMaterial.courseContent()");
		return "1.OOPS Concept 2.Exception Handling 3.Collection Handling...";
	}

	@Override
	public float price() {
		return 400;
	}

}
