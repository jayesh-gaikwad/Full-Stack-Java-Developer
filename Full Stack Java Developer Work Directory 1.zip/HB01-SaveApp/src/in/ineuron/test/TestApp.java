package in.ineuron.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.ineuron.model.Student;


public class TestApp {

	public static void main(String[] args) throws Exception {
		
		//1.Inform the JVM to activate the HIBERNATE
		//First create the configuration object and configure with hibernate.cfg.xml file.
		Configuration configuration=new Configuration();
		configuration.configure();
		
		
		//configuration.addClass(in.ineuron.model.Student.class);
		//configuration.addResource("myFile.hbm.xml");
		
		
		//2.Create a sessionFactory object to hold many objects required for HIBERNATE
		SessionFactory sessionFatcory=configuration.buildSessionFactory();
		
		//3.Using sessionFactory objects, get only one Session object to perform our persistence Operation.
		Session session=sessionFatcory.openSession(); //connection object,ORM-Dialects,L1-Cache ,TRXNManagement
		 
		Transaction transaction= session.beginTransaction();//transaction.begin()
		
		
		//4.Create a persistence object and set the values.
		Student student=new Student();
		student.setSid(07);
		student.setSname("MSD");
		student.setSaddress("CSK");
		student.setSage(42);
		
		//5.Perform PERSISTANCE operation using Entity/POJO/Model Object.
		session.save(student);
		
		System.in.read();
		
		//6.Commit the transaction based on the result.
		transaction.commit();
		
		System.out.println("Object save to the database");
		
		session.close();
		sessionFatcory.close();
			
	}

}
