package in.ineuron.comp;

public class BlueDart implements Courier {

	static {
		System.out.println("BlueDart .class file loading");
	}

	public BlueDart() {
		System.out.println("BlueDart:: Zero Param Constructor");
	}

	@Override
	public String deliver(int oid) {
		System.out.println("BlueDart.deliver()");
		return "BlueDart Courier will delievered with order id ::"+ oid +"for the ordered products";
	}

}
