package in.ineuron.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

//It gives utility to StudentDaoImpl Class
//Complete 
public class JdbcUtil {

	// Here used Private Constructor BCZ It restricts the class instances within the
	// declared class so that no class instance can be created outside the declared
	// class.
	private JdbcUtil() {

	}
	
	static {
		//Step1:Loading and register the driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getJdbcConnection() throws SQLException,IOException{
		
		
		return physicalConnection();
		
	}

	private static Connection physicalConnection() throws FileNotFoundException,IOException,SQLException{
		
		String fileLoc="C:\\Programming lang\\Full-Stack-Java-Developer\\MVCCrudApp\\src\\in\\ineuron\\properties\\application.properties";
		FileInputStream fis=new FileInputStream(fileLoc);
		Properties properties=new Properties();
		properties.load(fis);
		
		String url=properties.getProperty("jdbcUrl");
		String username=properties.getProperty("user");
		String password=properties.getProperty("password");
		
		
		return DriverManager.getConnection(url,username,password);
	}
	

}
