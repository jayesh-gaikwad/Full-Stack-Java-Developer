package in.ineuron.comp;

public class DTDC implements Courier {

	static {
		System.out.println("DTDC .class is loading");
	}

	public DTDC() {
		System.out.println("DTDC zero paramater constructor");
	}

	@Override
	public String deliver(int oid) {

		System.out.println("DTDC.deliver()");
		return "DTDC Courier will be delivered with order id" + oid + 
				"for the ordered products";
	}

}
