package in.ineuron.test;

import in.ineuron.comp.WishMessageGenerator;

public class UsingCoreJavaApp {

	public static void main(String[] args) {
		
		WishMessageGenerator generator=new WishMessageGenerator();
		System.out.println("Target Object Before Setter Injection is:: "+generator);

		System.out.println();
		
		java.util.Date date=new java.util.Date();
		System.out.println("Dependent object is::"+date);
		System.out.println();
		
		generator.setDate(date);
		
		System.out.println("Target Object after setter injection :: "+generator);
		
		System.out.println();
		
		String result=generator.generateMessage("Jayesh");
		
		System.out.println(result);
	}

}
