package in.ineuron.comp;

import java.util.Date;

//Target Class(userDefined=>WishMessageGenerator)
public class WishMessageGenerator {

	// Dependent Class(preDefined=> java.util.Date)
	private Date date;

	static {
		System.out.println("WishMessageGenerator .class file is loading");
	}

	public WishMessageGenerator() {
		System.out.println("WishMessageGenerator object is instantiated");
	}

	//Setter Method to perform setter injection 
	public void setDate(Date date) {
		this.date = date;
		System.out.println("Setter Method is called to perform Setter Injection");
	}

	
	// Business Logic method => Using Dependent object in B.L.

	public String generateMessage(String userName) {
		@SuppressWarnings("deprecation")
		int hour = date.getHours(); // To get hour in 24 hour format

		if (hour < 12) {
			return "Good Morning:: " + userName;
		} else if (hour < 16) {
			return "Good Afternoon:: " + userName;
		} else if (hour < 20) {
			return "Good Evening:: " + userName;
		} else {
			return "Good Night:: " + userName;
		}

	}

	public String toString() {
		return "WellMessageGenerator [date=" + date + "]";
	}
}
