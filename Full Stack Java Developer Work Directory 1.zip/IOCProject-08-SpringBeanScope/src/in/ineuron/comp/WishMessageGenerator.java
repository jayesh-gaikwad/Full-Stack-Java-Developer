package in.ineuron.comp;

import java.util.Date;

//Target Class->User defined class(WishMessageGenerator)
public class WishMessageGenerator {

	// Dependent Class->Predefined class(Date)
	public Date date;

	static {
		System.out.println("WishMessageGenerator.class file loading");
	}

	public WishMessageGenerator() {
		System.out.println("WishMessageGenerator object is initiated using::Zero Param Constructor");
	}

	public void setDate(Date date) {
		this.date = date;
		System.out.println("Setter Method is called to perform setter injection");
		System.out.println(this);
	}
	
	@Override
	public String toString() {
		return "WishMessageGenerator [date=" + date + "]";
	}
}
