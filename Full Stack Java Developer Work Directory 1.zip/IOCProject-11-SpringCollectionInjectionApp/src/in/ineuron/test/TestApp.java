package in.ineuron.test;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.ineuron.comp.PersonInfo;

public class TestApp {

	public static void main(String[] args) throws IOException {

		ClassPathXmlApplicationContext factory = new ClassPathXmlApplicationContext(
				"in/ineuron/cfg/applicationContext.xml");
		System.out.println("************Conatiner Started************");
		System.out.println("Bean id id:: " + Arrays.toString(factory.getBeanDefinitionNames()));
		
		System.in.read();
		System.out.println();
		
		PersonInfo personInfo=factory.getBean("pinfo",PersonInfo.class);
		System.out.println(personInfo);
		
		factory.close();
		
		System.out.println("\n***********Container Stopped*************");
	}

}
