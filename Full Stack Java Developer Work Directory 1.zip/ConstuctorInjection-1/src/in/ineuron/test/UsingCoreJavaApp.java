package in.ineuron.test;

import java.util.Date;

import in.ineuron.comp.WishMessageGenerator;

public class UsingCoreJavaApp {

	public static void main(String[] args) {
		
		Date date=new java.util.Date();
		System.out.println("Creating an object of Dependent class using Zero Param Constuctor::"+date);
		
		WishMessageGenerator wmg=new WishMessageGenerator(date);
		System.out.println("Creating an object of Target class using parametrized Constructor::"+wmg);
		
		String result=wmg.generateMessage("Kohli");
		System.out.println(result);
	}

}
