package in.ineuron.service;

import in.ineuron.dto.EmployeeDto;

public interface SalaryDetailsGenerator {
	public void generateSalaryDetails(EmployeeDto dto);
}
